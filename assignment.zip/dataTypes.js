const Name = 'john';
const age = 25;
const isStudent = true;
const hobbies = ['reading', 'painting','and hiking'];
const address = {
    street:'123 Main Street',
    city:'Cityville',
    country:'Countryland'
};


// #1
console.log(`My name is ${Name}`);
// #2
console.log(`i am ${age} years old.`);
// #3
console.log(`I am a student:${isStudent}.`);
// #4
console.log(`My hobbies are ${hobbies}.`);
// #5
console.log(`I live at ${address.street}, ${address.city}, ${address.country}.`);