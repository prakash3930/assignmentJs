const age = 20;
const Name = 'prokash sarker';
const isStudent = true;
const birthYear = 2003;

// #1
console.log(`My name is ${Name} and i am ${age} years old.`);
// #2
console.log(`I am a student:${isStudent}.`);
// #3
console.log(`I was born in ${birthYear}.`);