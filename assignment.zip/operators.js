const num1 = 20;
const num2 = 50;
const sum = num1 + num2;
const difference = num1 - num2;
const product = num1 * num2;
const quotient = num1 / num2;
const remainder = num1 % num2;



// #1
console.log(`The sum is ${sum}`);
// #2
console.log(`The difference is  ${difference}`);
// #3
console.log(`The product is ${product}`);
// #4
console.log(`The quotient is  ${quotient}`);
// #5
console.log(`The remainder is ${remainder}`);